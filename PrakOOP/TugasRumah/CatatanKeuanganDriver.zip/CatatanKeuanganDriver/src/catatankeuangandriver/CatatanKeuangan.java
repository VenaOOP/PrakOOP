/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package catatankeuangandriver;
import java.util.ArrayList;
/**
 *
 * @author 62821
 */
// Kelas abstrak CatatanKeuangan yang menyimpan informasi transaksi keuangan
public abstract class CatatanKeuangan {
    private double saldoAkhir; // Menyimpan saldo akhir setelah transaksi
    private ArrayList<Transaksi> transaksiList; // Menyimpan daftar transaksi

    // Konstruktor untuk inisialisasi objek CatatanKeuangan
    public CatatanKeuangan() {
        saldoAkhir = 0.0;
        transaksiList = new ArrayList<>();
    }

    // Metode abstrak untuk memproses data input transaksi
    public abstract void prosesDataInput(String jenis, String keterangan, double jumlah);

    public void tambahTransaksi(String jenis, String keterangan, double jumlah) throws IllegalArgumentException {
        if (jumlah <= 0) {
            throw new IllegalArgumentException("Jumlah transaksi harus lebih dari 0.");
        }

        Transaksi transaksi = new Transaksi(jenis, keterangan, jumlah);
        transaksiList.add(transaksi);
        if (jenis.equals("Pemasukan")) {
            saldoAkhir += jumlah;
        } else if (jenis.equals("Pengeluaran")) {
            if (saldoAkhir < jumlah) {
                throw new IllegalArgumentException("Saldo tidak mencukupi untuk transaksi pengeluaran.");
            }
            saldoAkhir -= jumlah;
        }
    }

    // Metode untuk mengambil total pemasukan dari daftar transaksi
    public double getTotalPemasukan() {
        double totalPemasukan = 0.0;
        for (Transaksi transaksi : transaksiList) {
            if (transaksi.getJenis().equals("Pemasukan")) {
                totalPemasukan += transaksi.getJumlah();
            }
        }
        return totalPemasukan;
    }

    // Metode untuk mengambil total pengeluaran dari daftar transaksi
    public double getTotalPengeluaran() {
        double totalPengeluaran = 0.0;
        for (Transaksi transaksi : transaksiList) {
            if (transaksi.getJenis().equals("Pengeluaran")) {
                totalPengeluaran += transaksi.getJumlah();
            }
        }
        return totalPengeluaran;
    }

    // Metode untuk mengambil saldo akhir setelah transaksi
    public double getSaldoAkhir() {
        return saldoAkhir;
    }
}

// Kelas yang merepresentasikan transaksi keuangan
class Transaksi {
    private String jenis; // Jenis transaksi (Pemasukan atau Pengeluaran)
    private String keterangan; // Keterangan transaksi
    private double jumlah; // Jumlah uang transaksi

    // Konstruktor untuk inisialisasi objek Transaksi
    public Transaksi(String jenis, String keterangan, double jumlah) {
        this.jenis = jenis;
        this.keterangan = keterangan;
        this.jumlah = jumlah;
    }

    // Metode untuk mengambil jenis transaksi
    public String getJenis() {
        return jenis;
    }

    // Metode untuk mengambil jumlah uang transaksi
    public double getJumlah() {
        return jumlah;
    }
}
