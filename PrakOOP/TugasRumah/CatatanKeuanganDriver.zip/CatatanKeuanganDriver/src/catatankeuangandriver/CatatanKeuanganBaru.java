/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package catatankeuangandriver;
import java.util.ArrayList;
/**
 *
 * @author 62821
 */
// Kelas CatatanKeuanganBaru yang merupakan turunan dari kelas CatatanKeuangan
public class CatatanKeuanganBaru extends CatatanKeuangan {
    private String sumberData;  // Variabel untuk menyimpan informasi sumber data

    // Konstruktor tanpa argumen
    public CatatanKeuanganBaru() {
        super(); // Panggil konstruktor kelas induk
    }

    // Konstruktor dengan argumen, memanggil konstruktor kelas induk
    public CatatanKeuanganBaru(String sumberData) {
        super(); // Panggil konstruktor kelas induk
        this.sumberData = sumberData;
    }

    // Metode khusus untuk CatatanKeuanganBaru
    public void tambahTransaksiBaru(String jenis, String keterangan, double jumlah, String kategori) {
        super.tambahTransaksi(jenis, keterangan, jumlah);
        // Implementasi tambahan khusus CatatanKeuanganBaru
    }

    // Metode getter untuk mendapatkan nilai sumberData
    public String getSumberData() {
        return sumberData;
    }

    // Metode setter untuk mengatur nilai sumberData
    public void setSumberData(String sumberData) {
        this.sumberData = sumberData;
    }

    // Overriding metode tambahTransaksi untuk menyertakan metode khusus CatatanKeuanganBaru
    @Override
    public void tambahTransaksi(String jenis, String keterangan, double jumlah) {
        super.tambahTransaksi(jenis, keterangan, jumlah);
    }
    
    @Override
    public void prosesDataInput(String jenis, String keterangan, double jumlah) {
        // Implementasi proses data input sesuai kebutuhan kelas CatatanKeuanganBaru
        tambahTransaksiBaru(jenis, keterangan, jumlah, "KategoriBaru");

        // Sisanya diwarisi dari kelas induk
    }
}