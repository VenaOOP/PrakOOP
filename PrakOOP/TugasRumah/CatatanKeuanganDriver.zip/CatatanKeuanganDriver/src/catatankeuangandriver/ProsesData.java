/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package catatankeuangandriver;

/**
 *
 * @author 62821
 */
public interface ProsesData {
    void prosesDataInput(String jenis, String keterangan, double jumlah);
}
