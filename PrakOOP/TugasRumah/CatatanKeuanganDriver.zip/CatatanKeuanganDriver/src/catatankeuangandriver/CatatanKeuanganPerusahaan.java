/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package catatankeuangandriver;
import java.util.ArrayList;
/**
 *
 * @author 62821
 */
// Kelas CatatanKeuanganPerusahaan yang merupakan turunan dari kelas CatatanKeuangan
public class CatatanKeuanganPerusahaan extends CatatanKeuangan implements ProsesData{
    private String namaPerusahaan;  // Variabel untuk menyimpan nama perusahaan

    // Konstruktor tanpa argumen
    public CatatanKeuanganPerusahaan() {
        super();  // Memanggil konstruktor superclass CatatanKeuangan
        namaPerusahaan = "";
    }

    // Konstruktor dengan argumen, memanggil konstruktor superclass CatatanKeuangan
    public CatatanKeuanganPerusahaan(String namaPerusahaan) {
        super();  // Memanggil konstruktor superclass CatatanKeuangan
        this.namaPerusahaan = namaPerusahaan;
    }

    // Metode getter untuk mendapatkan nilai namaPerusahaan
    public String getNamaPerusahaan() {
        return namaPerusahaan;
    }

    // Metode setter untuk mengatur nilai namaPerusahaan
    public void setNamaPerusahaan(String namaPerusahaan) {
        this.namaPerusahaan = namaPerusahaan;
    }

    // Metode khusus untuk CatatanKeuanganPerusahaan
    public void tambahTransaksiPerusahaan(String jenis, String keterangan, double jumlah, String departemen) {
        super.tambahTransaksi(jenis, keterangan, jumlah);
        // Implementasi tambahan khusus CatatanKeuanganPerusahaan
    }

    // Overriding metode tambahTransaksi untuk menyertakan metode khusus CatatanKeuanganPerusahaan
    @Override
    public void tambahTransaksi(String jenis, String keterangan, double jumlah) {
        super.tambahTransaksi(jenis, keterangan, jumlah);
    }
    
    @Override
    public void prosesDataInput(String jenis, String keterangan, double jumlah) {
        // Implementasi proses data input sesuai kebutuhan kelas CatatanKeuanganPerusahaan
        tambahTransaksiPerusahaan(jenis, keterangan, jumlah, "DepartemenBaru");

        // Sisanya diwarisi dari kelas induk
    }
}


